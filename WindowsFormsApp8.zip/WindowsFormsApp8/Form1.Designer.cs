﻿partial class MainForm
{
   
    private System.ComponentModel.IContainer components = null;

    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code
    private void InitializeComponent()
    {
        this.btnCopy = new System.Windows.Forms.Button();
        this.btnCancel = new System.Windows.Forms.Button();
        this.btnPause = new System.Windows.Forms.Button();
        this.progressBar = new System.Windows.Forms.ProgressBar();
        this.lblSpeed = new System.Windows.Forms.Label();
        this.txtBufferSize = new System.Windows.Forms.TextBox();
        this.SuspendLayout(); 
        this.btnCopy.Location = new System.Drawing.Point(12, 12);
        this.btnCopy.Name = "btnCopy";
        this.btnCopy.Size = new System.Drawing.Size(75, 23);
        this.btnCopy.TabIndex = 0;
        this.btnCopy.Text = "Copy";
        this.btnCopy.UseVisualStyleBackColor = true;
        this.btnCopy.Click += new System.EventHandler(this.btnCopy_Click);
        this.btnCancel.Location = new System.Drawing.Point(93, 12);
        this.btnCancel.Name = "btnCancel";
        this.btnCancel.Size = new System.Drawing.Size(75, 23);
        this.btnCancel.TabIndex = 1;
        this.btnCancel.Text = "Cancel";
        this.btnCancel.UseVisualStyleBackColor = true;
        this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
        this.btnPause.Location = new System.Drawing.Point(174, 12);
        this.btnPause.Name = "btnPause";
        this.btnPause.Size = new System.Drawing.Size(75, 23);
        this.btnPause.TabIndex = 2;
        this.btnPause.Text = "Pause";
        this.btnPause.UseVisualStyleBackColor = true;
        this.btnPause.Click += new System.EventHandler(this.btnPause_Click);
        this.progressBar.Location = new System.Drawing.Point(12, 41);
        this.progressBar.Name = "progressBar";
        this.progressBar.Size = new System.Drawing.Size(237, 23);
        this.progressBar.TabIndex = 3;
    
        this.lblSpeed.AutoSize = true;
        this.lblSpeed.Location = new System.Drawing.Point(12, 71);
        this.lblSpeed.Name = "lblSpeed";
        this.lblSpeed.Size = new System.Drawing.Size(0, 13);
        this.lblSpeed.TabIndex = 4;
 
        this.txtBufferSize.Location = new System.Drawing.Point(255, 12);
        this.txtBufferSize.Name = "txtBufferSize";
        this.txtBufferSize.Size = new System.Drawing.Size(100, 20);
        this.txtBufferSize.TabIndex = 5;
        this.txtBufferSize.Text = "1024"; 
       
        this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(367, 104);
        this.Controls.Add(this.txtBufferSize);
        this.Controls.Add(this.lblSpeed);
        this.Controls.Add(this.progressBar);
        this.Controls.Add(this.btnPause);
        this.Controls.Add(this.btnCancel);
        this.Controls.Add(this.btnCopy);
        this.Name = "MainForm";
        this.Text = "File Copy Utility";
        this.ResumeLayout(false);
        this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Button btnCopy;
    private System.Windows.Forms.Button btnCancel;
    private System.Windows.Forms.Button btnPause;
    private System.Windows.Forms.ProgressBar progressBar;
    private System.Windows.Forms.Label lblSpeed;
    private System.Windows.Forms.TextBox txtBufferSize;
}
