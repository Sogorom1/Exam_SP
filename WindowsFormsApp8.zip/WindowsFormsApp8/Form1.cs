﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.Linq;

public partial class MainForm : Form
{
    private CancellationTokenSource cancelTokenSource;
    private long totalBytesCopied;
    private long totalFileSize;
    private bool isCopyingPaused;

    public MainForm()
    {
        InitializeComponent();
    }

    private void btnCopy_Click(object sender, EventArgs e)
    {
        string sourcePath = "C:\\Users\\77079\\Desktop\\Baha\\обои на рабочий стол";
        string destinationPath = "C:\\Users\\77079\\Desktop\\Baha";
        int bufferSize = int.Parse(txtBufferSize.Text); 

        cancelTokenSource = new CancellationTokenSource();
        totalBytesCopied = 0;
        isCopyingPaused = false;

        ThreadPool.QueueUserWorkItem(state =>
        {
            CopyFiles(sourcePath, destinationPath, bufferSize, cancelTokenSource.Token);
        });
    }

    private void btnCancel_Click(object sender, EventArgs e)
    {
        cancelTokenSource?.Cancel();
        progressBar.Value = 0;
        lblSpeed.Text = "";
    }

    private void btnPause_Click(object sender, EventArgs e)
    {
        isCopyingPaused = !isCopyingPaused;
        btnPause.Text = isCopyingPaused ? "Возобновить" : "Приостановить";
    }


    private void CopyFiles(string sourcePath, string destinationPath, int bufferSize, CancellationToken cancellationToken)
    {
        try
        {
            string[] files = Directory.GetFiles(sourcePath);
            totalFileSize = files.Sum(file => new FileInfo(file).Length);

            foreach (var file in files)
            {
                if (cancellationToken.IsCancellationRequested)
                    break;

                using (var sourceStream = new FileStream(file, FileMode.Open, FileAccess.Read))
                using (var destStream = new FileStream(Path.Combine(destinationPath, Path.GetFileName(file)), FileMode.Create, FileAccess.Write))
                {
                    byte[] buffer = new byte[bufferSize];
                    int bytesRead;
                    DateTime startTime = DateTime.Now;

                    while ((bytesRead = sourceStream.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        if (cancellationToken.IsCancellationRequested)
                            break;

                        if (isCopyingPaused)
                        {
                            Thread.Sleep(500);
                            continue;
                        }

                        destStream.Write(buffer, 0, bytesRead);
                        totalBytesCopied += bytesRead;
                        double percentage = (double)totalBytesCopied / totalFileSize * 100;
                        TimeSpan elapsedTime = DateTime.Now - startTime;
                        double speed = totalBytesCopied / elapsedTime.TotalSeconds;

                        UpdateProgress((int)percentage, speed);
                    }
                }
            }
        }
        catch (OperationCanceledException)
        {
            MessageBox.Show("Копирование отменено.");
        }
        catch (Exception ex)
        {
            MessageBox.Show("Произошла ошибка: " + ex.Message);
        }
    }

    private void UpdateProgress(int percentage, double speed)
    {
        if (InvokeRequired)
        {
            Invoke((MethodInvoker)(() => UpdateProgress(percentage, speed)));
        }
        else
        {
            progressBar.Value = percentage;
            lblSpeed.Text = $"{speed / 1024:F2} Кб/сек";
        }
    }
}
